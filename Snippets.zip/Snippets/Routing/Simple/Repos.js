import React, { Component } from 'react';
class Repos extends Component {
render() {
return (
<h1>Github Repos</h1>
);
}
}
export default Repos;