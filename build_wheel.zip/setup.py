# Array of all currencies
currencyList = ['AUD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'INR', 'JPY', 'NOK', 'NZD', 'SEK', 'USD']
# Array of dictionaries, where each dictionary represents a row in the FXSkew Grid
fxskewTable = []
# Array for all Skew Types entered by the user in the FXSkew Grid
allSkewTypes = []

# Function to check Currency Format Rules
# Input Parameters: Newly added row to the FXSkew Grid, Array of dictionaries representing the FXSKew Grid
# Returns the newly added row and the array of dictionary with corresponding status message
def checkCurrencyFormatRules(fxskewRow, fxskewTable):
  # Check whether the currency pair is 6 characters or not, Eg: 'TUH', 'USD'
  if len(fxskewRow['identifierValue']) != 6:
    fxskewRow['statusMessage'] = 'Not a valid Currency Pair/Rule'
    fxskewRow['statusCheck'] = 'Failure'
  else:
    # Check whether invalid currencies have been entered, Eg: 'INRPOM', 'OTIYHM'
    if (fxskewRow['identifierValue'][:3] not in currencyList) or (fxskewRow['identifierValue'][-3:] not in currencyList):
      fxskewRow['statusMessage'] = 'Not a valid Currency Pair/Rule'
      fxskewRow['statusCheck'] = 'Failure'
    else:
      # Check whether same currency has been used in a pair, Eg: 'USDUSD', 'JPYJPY'
      if fxskewRow['identifierValue'][:3] == fxskewRow['identifierValue'][-3:]:
        fxskewRow['statusMessage'] = 'Currency Pair/Rule cannot have the same currency'
        fxskewRow['statusCheck'] = 'Failure'
      else:
        for index in range(len(fxskewTable)):
          # Check whether the grid contains duplicate currency pairs, Eg: 'USDINR' and 'USDINR' for same Skew Type
          if (fxskewTable[index]['identifierValue'] == fxskewRow['identifierValue']) and (fxskewTable[index]['skewType'] == fxskewRow['skewType']):
            fxskewTable[index]['statusMessage'] = 'Same Currency Pair/Skew Type cannot be defined more than once in the grid'
            fxskewRow['statusMessage'] = 'Same Currency Pair/Skew Type cannot be defined more than once in the grid'
            fxskewTable[index]['statusCheck'] = 'Failure'
            fxskewRow['statusCheck'] = 'Failure'
          # Check whether the grid contains duplicate currency pairs in inverted order, Eg: 'USDINR' and 'INRUSD' for same Skew Type
          if ((fxskewTable[index]['identifierValue'][-3:] + fxskewTable[index]['identifierValue'][:3]) == fxskewRow['identifierValue']) and (fxskewTable[index]['skewType'] == fxskewRow['skewType']):
            fxskewTable[index]['statusMessage'] = 'Same Currency Pair/Skew Type cannot be defined more than once by interchanging the currency'
            fxskewRow['statusMessage'] = 'Same Currency Pair/Skew Type cannot be defined more than once by interchanging the currency'
            fxskewTable[index]['statusCheck'] = 'Failure'
            fxskewRow['statusCheck'] = 'Failure'
  return fxskewRow, fxskewTable

# Function to check Triangle Rule
# Input Parameters: Array of dictionaries representing the FXSKew Grid, array of skew types entered in the FXSkew Grid
# Returns the array of dictionary with corresponding status message
def checkTriangleRule(fxskewTable, allSkewTypes):
  for skewType in allSkewTypes:
    withUSD = []
    for index in range(len(fxskewTable)):
      # Continue the iteration if there is a Red Flag or a different Skew Type
      if fxskewTable[index]['statusCheck'] == 'Failure' or fxskewTable[index]['skewType'] != skewType:
        continue
      # Add all currencies added with 'USD' into an array called 'withUSD'
      if 'USD' in fxskewTable[index]['identifierValue']:
        withUSD.append(fxskewTable[index]['identifierValue'].replace('USD', ''))
    # Check for invalid pairs based on the array called 'withUSD' according to the Triangle Rule
    for index in range(len(fxskewTable)):
      if fxskewTable[index]['statusCheck'] == 'Failure' or fxskewTable[index]['skewType'] != skewType:
        continue
      if (fxskewTable[index]['identifierValue'][-3:] in withUSD) and (fxskewTable[index]['identifierValue'][:3] in withUSD):
        fxskewTable[index]['statusMessage'] = 'Not a valid currency pair for a given skew type as per the triangle rule'
        fxskewTable[index]['statusCheck'] = 'Failure'
  return fxskewTable

# Loop to constantly take use input, and perform all Currency Pair and Triangle Rule Checks
while(True):
  fxskewRow = {}
  fxskewRow['skewType'], fxskewRow['identifierValue'], fxskewRow['statusCheck'], fxskewRow['statusMessage']  = [x.upper() for x in input().split()] + ['Success', 'Success']
  if fxskewRow['skewType'] not in allSkewTypes:
    allSkewTypes.append(fxskewRow['skewType'])
  fxskewRow, fxskewTable = checkCurrencyFormatRules(fxskewRow, fxskewTable)
  fxskewTable.append(fxskewRow)
  clear_output()
  displayUI(checkTriangleRule(fxskewTable, allSkewTypes))
